# Program that display all numbers in file
# 28 Jun 2017
# CTI-110 M6T1 - File Display
# Radhames Flete Perez


def main():

    file = open('numbers.txt','r')

    for line in file:
        number=int(line)
        print(number)

    file.close()

main()
