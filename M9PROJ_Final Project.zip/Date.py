# Program that say the date and time.
# 20 July 2017
# CTI-110 M9PROJ - Final Project 
# Radhames Flete Perez



def Dates():
    
    import time
    
    date = time.strftime("%x")
    time = time.strftime("%H:%M:%S")
    finalTime = date +" "+time
    
    return finalTime
    

