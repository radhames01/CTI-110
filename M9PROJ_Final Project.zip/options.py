# Program that holds differents menus 
# 20 July 2017
# CTI-110 M9PROJ - Final Project 
# Radhames Flete Perez



def selection():
    print("Select the Operation\n")
    print("1 - Sum ")
    print("2 - Subtraction")
    print("3 - Multiplication")
    print("4 - Division")
   



def continued():
    print("Another Operation? Y/N")
    c = input("")
    y = 1
    
    if c == 'y' or c == 'Y':
        print("\n"*10)
        return y
        
    else:
        print("Good Bye")



