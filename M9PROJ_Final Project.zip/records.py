# Program that saves the records
# 20 July 2017
# CTI-110 M9PROJ - Final Project 
# Radhames Flete Perez



def main(A):

    import Date
 

    num=A
    a=str(num)
    D = Date.Dates()
    file=open('records.txt','a')

    r = file.write("Result: "+a+"\n"+"\n")   
   
    file.close()
    

def types(B):
    import Date
    
    o=str(B)
    
    D = Date.Dates()
    file=open('records.txt','a')
    
    
    r = file.write(D+"\n"+"Operation:"+o+"\n")
    
    file.close()
    
