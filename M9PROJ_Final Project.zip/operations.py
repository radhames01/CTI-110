# Program that holds the differents type of operations
# 20 July 2017
# CTI-110 M9PROJ - Final Project 
# Radhames Flete Perez




def sums():
    try:
        a = float(input("enter the first value.\n"))
        b = float(input("Enter the second valuen.\n"))
        sum = a+b
        return sum
    
    except ValueError as ERR:
        print("Please enter Numeric values.\n",ERR)
    
def subtraction():
    try:
        a = float(input("enter the first value.\n"))
        b = float(input("Enter the second value.\n"))
        sub = a - b
        return sub

    except ValueError as ERR:
        print("Please enter Numeric values.\n",ERR)

def multiplication():
    try:
        a = float(input("Enter the first value to be Multiplied.\n"))
        b = float(input("Enter the second value to be Multiplied.\n"))
        mult = a * b
        return mult
    
    except ValueError as ERR:
        print("Please enter Numeric values.\n",ERR)

def division():
    try:
        a = float(input("Enter the value to be dividend.\n"))
        b = float(input("Enter the divisor.\n"))
        div = a / b
        return div
    
    except ValueError as ERR:
        print("Please enter Numeric values.\n",ERR)

    except ZeroDivisionError as ERR:
        print("Can not divide by Zero.\n",ERR)
