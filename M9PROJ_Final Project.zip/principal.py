# Program that combine menus and operation to emulate a calculator 
# 20 July 2017
# CTI-110 M9PROJ - Final Project 
# Radhames Flete Perez


import operations
import options
import records

op = operations
ot = options
r = records

def main():
    
    ot.selection()
    
    x = int(input(""))
    y=x
    
    if y < 1 or x > 4:
        print("Please Enter a valid Option.\n")
        main()

    while x == 1:
        result = op.sums()
        
        Z = "Sum"
        r.types(Z)
        r.main(result)
                
        if result !=None:
            print("The Result of the Sum is:",result)
            print("\n")
        else:
            print("")
            
        x = 0
        
    while x == 2:
        result = op.subtraction()
        
        Z = "Subtraction"
        r.types(Z)
        r.main(result)
        
        
        if result !=None:
            print("The Result of the Subtraction is:",result)
            print("\n")
        else:
            print("")
        
        
        x=0
        
    while x == 3:
        result = op.multiplication()
        
        Z = "Multiplication"
        r.types(Z)
        r.main(result)
        
                
        if result !=None:
            print("The Result of the Multiplication is:",result)
            print("\n")
        else:
            print("")
        
        
        x=0
        
    while x == 4:
        result = op.division()
        
        Z = "Division"
        r.types(Z)
        r.main(result)
        
               
        if result !=None:
            print("The Result of the Division is:",result)
            print("\n")
        else:
            print("")
        
        
        x=0
        
    s = ot.continued()
    if s == 1:
        main()


main()
input()
